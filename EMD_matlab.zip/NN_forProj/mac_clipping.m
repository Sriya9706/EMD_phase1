%% Script to run inference of pre-trained Neural Network on 10k Images of MNIST Test Set

clc;
clear;
close all;

%% Load neural network Weights and Biases
load('weightsAndBiases.mat', 'W1', 'b1', 'W2', 'b2');

%% Load test set images and labels
images = loadMNISTImages('t10k-images');
labels = loadMNISTLabels('t10k-labels')';

%% Optional histograms of raw values
figure;
histogram(W1(:));
title('Histogram of W1');

figure;
histogram(images(:));
title('Histogram of input images');

%% Layer 1 quantization
W1_Q    = fi(W1,    1, 6, 4);   % signed, WL=6, FL=4
images_Q = fi(images, 0, 2, 2); % unsigned, WL=2, FL=2

%% Forward pass using quantized values
z1 = W1_Q.data * images_Q.data + b1;
a1 = max(0, z1);   % ReLU

%% Histogram of all MAC values
MacV = W1_Q.data* images_Q.data;
figure;
grid("on")
histogram(MacV);
title('Histogram of all partial MAC values');

fprintf('Maximum MAC value = %g\n', max(max(MacV)));

fprintf('Minimum MAC value = %g\n', min(min(MacV)));

mu = mean(MacV(:))
sigma = std(MacV(:))

delta = 2.94; %for B = 5
% Optimal range=[μ−ζσ,μ+ζσ]

optimalRange = [mu - delta * sigma, mu + delta * sigma];
fprintf('Optimal range = [%g, %g]\n', optimalRange(1), optimalRange(2));