WL = W1_Q.WordLength;         % 6
F  = W1_Q.FractionLength;     % 4

Ws = storedInteger(W1_Q);     % signed stored integers
Wu = mod(double(Ws), 2^WL); % convert to unsigned 2's complement form

Wb = cell(1, WL);           % 6 bit-plane matrices
weightsW = zeros(1, WL);     % corresponding bit weights

for b = 1:WL
    Wb{b} = bitget(Wu, b);   % b=1 is LSB, b=6 is MSB
    if b == WL
        weightsW(b) = -2^(WL-F-1);   % sign bit weight
    else
        weightsW(b) = 2^(b-1-F);
    end
end






WL = images_Q.WordLength;         % 2
F  = images_Q.FractionLength;     % 2

Xs = storedInteger(images_Q);     % unsigned stored integers
Xu = double(Xs);                  % no need for 2's complement conversion

Xb = cell(1, WL);                % 2 bit-plane matrices
weightsX = zeros(1, WL);           % corresponding bit weights

for b = 1:WL
    Xb{b} = bitget(Xu, b);        % b=1 is LSB, b=2 is MSB
    weightsX(b) = 2^(b-1-F);
end






%to reconstructs
Wrec = zeros(size(W1_Q));

for b = 1:WL
    Wrec = Wrec + double(Wb{b}) * weightsW(b);
end








MAC = cell(1, WL);
i = 1;
for a = 1:6
    for b = 1:2
        MAC{i} = Wb{a} * Xb{b};
        i = i + 1;
    end
end







all = [];

for i = 1:WL
    all = [all; MAC{i}(:)];
end

histogram(all);
maxxx = max(all)

histogram(MAC{1});