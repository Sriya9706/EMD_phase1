%% Script to run inference of pre-trained Neural Network on 10k Images of MNIST Test Set

clc;
clear;
close all;

%% Load neural network Weights and Biases
load('weightsAndBiases.mat', 'W1', 'b1', 'W2', 'b2');

%% Load test set images and labels
images = loadMNISTImages('t10k-images');
labels = loadMNISTLabels('t10k-labels')';

%% Optional histograms of raw values
figure;
histogram(W1);
title('Histogram of W1');

figure;
histogram(images);
title('Histogram of input images');

%% Layer 1 quantization
W1_Q    = fi(W1,    1, 6, 4);   % signed, WL=6, FL=4
X1_Q = fi(images, 0, 2, 2); % unsigned, WL=2, FL=2% W_Q: 10000 x 784

MAC_Q = W1_Q.data * X1_Q.data;

%% Pad to 1024 columns
W_Q = [W1_Q zeros(size(W1_Q,1), 1024 - size(W1_Q,2))];

% Split into 8 matrices (10000 x 128 each)
W_split = mat2cell(W_Q, size(W_Q,1), repmat(128,1,8));

% Optional access:
% W1 = W_split{1}; ... W8 = W_split{8};


%% Pad rows (784 → 1024)
X_Q = [X1_Q; zeros(1024 - size(X1_Q,1), size(X1_Q,2))];

% Split into 8 matrices (128 x 10000 each)
X_split = mat2cell(X_Q, repmat(128,1,8), size(X_Q,2));

% Optional:
% X1 = X_split{1}; ... X8 = X_split{8};

%% MAC of 128 
MAC = cell(1, 8);

i = 1;
%final_mac = zeros(100, 10000);
for a = 1:8
    MAC{a} = W_split{a}.data * X_split{a}.data;
    i = i + 1;    
    
end

%% Flatten all MAC values into one vector
allMAC = [];

for i = 3:3
    allMAC = [allMAC; MAC{i}(:)];
end

figure;
histogram(allMAC);
%hold on;
title('Histogram of MAC');

max_v = max(allMAC)
min_v = min(allMAC)

%% verification
final_mac = zeros(100, 10000);
for a = 1:8  
    final_mac = final_mac + MAC{a};
end

%% optimal clipping

mu = mean(allMAC)
sigma = std(allMAC)

delta = 2.94; %for B = 5
% Optimal range=[μ−ζσ,μ+ζσ]

optimalRange = [mu - delta * sigma, mu + delta * sigma];
fprintf('Optimal range = [%g, %g]\n', optimalRange(1), optimalRange(2));



x = linspace(min(allMAC), max(allMAC), 1000);
y = normpdf(x, mu, sigma);

%figure;
plot(x, y, 'r', 'LineWidth', 2);
hold off;

%figure;
%plot(x, y, 'r', 'LineWidth', 2);
%hold off;

figure
histogram(allMAC, 100, 'Normalization', 'pdf');
hold on;

x = linspace(min(allMAC), max(allMAC), 1000);
y = normpdf(x, mu, sigma);

plot(x, y, 'r', 'LineWidth', 2);
hold off;