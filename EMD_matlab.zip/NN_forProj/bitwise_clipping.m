%% Script to run inference of pre-trained Neural Network on 10k Images of MNIST Test Set

clc;
clear;

%% Load neural network Weights and Biases
load('weightsAndBiases.mat', 'W1', 'b1', 'W2', 'b2');

%% Load test set images and labels
images = loadMNISTImages('t10k-images');
labels = loadMNISTLabels('t10k-labels')';

%% Optional histograms of raw values
figure;
histogram(W1(:));
title('Histogram of W1');

figure;
histogram(images(:));
title('Histogram of input images');

%% Layer 1 quantization
W1_Q    = fi(W1,    1, 6, 4);   % signed, WL=6, FL=4
images_Q = fi(images, 0, 2, 2); % unsigned, WL=2, FL=2

%% Forward pass using quantized values
z1 = W1_Q.data * images_Q.data + b1;
a1 = max(0, z1);   % ReLU

%% -----------------------------
%% Bit-plane decomposition of W1
%% -----------------------------
WL_W = W1_Q.WordLength;          % 6
F_W  = W1_Q.FractionLength;      % 4

Ws = storedInteger(W1_Q);        % signed stored integers
Wu = mod(double(Ws), 2^WL_W);    % unsigned 2's complement representation

Wb = cell(1, WL_W);              % 6 bit-plane matrices
weightsW = zeros(1, WL_W);       % corresponding bit weights

for b = 1:WL_W
    Wb{b} = bitget(Wu, b);       % b=1 is LSB, b=WL_W is MSB
    if b == WL_W
        weightsW(b) = -2^(WL_W - F_W - 1);   % sign bit weight
    else
        weightsW(b) = 2^(b - 1 - F_W);
    end
end

%% --------------------------------
%% Bit-plane decomposition of images
%% --------------------------------
WL_X = images_Q.WordLength;      % 2
F_X  = images_Q.FractionLength;  % 2

Xs = storedInteger(images_Q);    % unsigned stored integers
Xu = double(Xs);

Xb = cell(1, WL_X);              % 2 bit-plane matrices
weightsX = zeros(1, WL_X);       % corresponding bit weights

for b = 1:WL_X
    Xb{b} = bitget(Xu, b);       
    weightsX(b) = 2^(b - 1 - F_X);
end

%% Reconstruct W1 from bit-planes (sanity check)
Wrec = zeros(size(W1_Q));
for b = 1:WL_W
    Wrec = Wrec + double(Wb{b}) * weightsW(b);
end

fprintf('Max abs reconstruction error in W1 = %g\n', max(abs(double(W1_Q) - Wrec), [], 'all'));

%% -----------------------------------------
%% Build all partial MAC matrices (6 x 2 = 12)
%% -----------------------------------------
numMAC = WL_W * WL_X;
MAC = cell(1, numMAC);

i = 1;
for a = 1:WL_W
    for b = 1:WL_X
        MAC{i} = Wb{a} * Xb{b};   % partial MAC matrix
        i = i + 1;
    end
end

%% Flatten all MAC values into one vector
allMAC = [];

for i = 1:numMAC
    allMAC = [allMAC; MAC{i}(:)];
end

%% Histogram of all MAC values
figure;
histogram(allMAC);
title('Histogram of all partial MAC values');

fprintf('Maximum partial MAC value = %g\n', max(allMAC));

%% Histogram of one partial MAC
figure;
histogram(MAC{1}(:));
title('Histogram of MAC{1}');

%% ============================================================
%% FIND GOOD B_ADC AND ONE-SIDED CLIPPING POINT FOR MAC VALUES
%% ============================================================
%
% What we are doing:
% 1. Assume ADC range is [0, alpha]
% 2. Any MAC value above alpha is clipped to alpha
% 3. Remaining values are quantized using B_ADC bits
% 4. Compute MSE between original MAC values and quantized values
% 5. Repeat for many alpha and B_ADC values
%
% This minimizes numerical distortion, not directly NN accuracy.

data = double(allMAC(:));
data = data(data >= 0);   % one-sided physical clipping

data_max  = max(data);
data_mean = mean(data);
data_std  = std(data);

fprintf('\nMAC stats:\n');
fprintf('max  = %.4f\n', data_max);
fprintf('mean = %.4f\n', data_mean);
fprintf('std  = %.4f\n', data_std);

%% Search settings
B_range = 2:8;                  % ADC precisions to test
num_alpha_points = 150;         % number of clipping points to test

% One-sided clipping candidates from small value to full max
alpha_list = linspace(0.05*data_max, data_max, num_alpha_points);

num_B = length(B_range);
mse_matrix = zeros(num_B, num_alpha_points);
best_alpha_for_B = zeros(num_B, 1);
best_mse_for_B   = zeros(num_B, 1);

%% Main sweep
for b_idx = 1:num_B
    B_ADC = B_range(b_idx);
    L = 2^B_ADC;   % number of ADC levels

    for a_idx = 1:num_alpha_points
        alpha = alpha_list(a_idx);

        % Step 1: one-sided clipping
        % if x > alpha, force it to alpha
        x_clip = min(data, alpha);

        % Step 2: uniform quantization over [0, alpha]
        delta = alpha / (L - 1);
        x_q = round(x_clip / delta) * delta;

        % safety clamp
        x_q = min(max(x_q, 0), alpha);

        % Step 3: total distortion wrt original data
        mse_matrix(b_idx, a_idx) = mean((data - x_q).^2);
    end

    [best_mse_for_B(b_idx), idx_min] = min(mse_matrix(b_idx, :));
    best_alpha_for_B(b_idx) = alpha_list(idx_min);
end

%% Show best alpha for each B_ADC
fprintf('\nBest clipping point for each B_ADC:\n');
fprintf('------------------------------------------\n');
fprintf('B_ADC    alpha_opt         MSE\n');
fprintf('------------------------------------------\n');
for b_idx = 1:num_B
    fprintf('%2d       %10.4f      %10.6f\n', ...
        B_range(b_idx), best_alpha_for_B(b_idx), best_mse_for_B(b_idx));
end

%% Global best by minimum MSE
[global_best_mse, idx_global] = min(best_mse_for_B);
global_best_B = B_range(idx_global);
global_best_alpha = best_alpha_for_B(idx_global);

fprintf('\nGlobal best by pure MSE:\n');
fprintf('B_ADC     = %d bits\n', global_best_B);
fprintf('alpha_opt = %.4f\n', global_best_alpha);
fprintf('MSE       = %.6f\n', global_best_mse);

%% Practical choice:
% choose smallest B_ADC within tolerance of best MSE
tolerance_percent = 5;
threshold_mse = global_best_mse * (1 + tolerance_percent/100);

candidate_idx = find(best_mse_for_B <= threshold_mse, 1, 'first');

if ~isempty(candidate_idx)
    good_B = B_range(candidate_idx);
    good_alpha = best_alpha_for_B(candidate_idx);
    good_mse = best_mse_for_B(candidate_idx);

    fprintf('\nRecommended practical choice (within %d%% of best MSE):\n', tolerance_percent);
    fprintf('B_ADC     = %d bits\n', good_B);
    fprintf('alpha_opt = %.4f\n', good_alpha);
    fprintf('MSE       = %.6f\n', good_mse);
else
    fprintf('\nNo practical choice found within tolerance.\n');
end

%% Plot MSE vs clipping point for each B_ADC
figure;
hold on;
for b_idx = 1:num_B
    plot(alpha_list, mse_matrix(b_idx,:), 'LineWidth', 1.5);
end
xlabel('Clipping point \alpha');
ylabel('MSE');
title('MSE vs clipping point for different B_{ADC}');
legend(arrayfun(@(x) sprintf('%d-bit', x), B_range, 'UniformOutput', false), ...
       'Location', 'best');
grid on;

%% Plot best MSE vs B_ADC
figure;
plot(B_range, best_mse_for_B, '-o', 'LineWidth', 2);
xlabel('B_{ADC} (bits)');
ylabel('Minimum MSE');
title('Best achievable MSE vs B_{ADC}');
grid on;

%% Plot optimal clipping point vs B_ADC
figure;
plot(B_range, best_alpha_for_B, '-s', 'LineWidth', 2);
xlabel('B_{ADC} (bits)');
ylabel('Optimal clipping point \alpha_{opt}');
title('Optimal clipping point vs B_{ADC}');
grid on;

%% --------------------------------
%% Layer 2 and classification output
%% --------------------------------
z2 = W2 * a1 + b2;
[~, guesses] = max(z2, [], 1);
guesses = guesses - 1;

%% Get accuracy
NumMatches = sum(labels == guesses);
Acc = NumMatches / numel(labels) * 100;

%% Display accuracy
fprintf('\nInference Accuracy = %.4f %%\n', Acc);